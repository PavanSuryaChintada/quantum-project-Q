# Welcome!

This kata covers the Mermin-Peres magic square game, a well-known example of a nonlocal (entanglement) game.

In a nonlocal game, several cooperating players play a game against a referee answering the referee's questions. 
The players are free to share information (and even qubits!) before the game starts, 
but are forbidden from communicating with each other afterwards. 
Nonlocal games show that quantum entanglement can be used to increase the players' chance of winning 
beyond what would be possible with a purely classical strategy.

#### Theory

* [Mermin-Peres magic square game on Wikipedia](https://en.wikipedia.org/wiki/Quantum_pseudo-telepathy#The_Mermin-Peres_magic_square_game).
* Exercise 4 from the [assignment](http://edu.itp.phys.ethz.ch/fs13/atqit/sol01.pdf) from Advanced Topics in Quantum Information Theory course by Christandl and Renner.

#### Q#

* Consider solving [JointMeasurements kata](./../JointMeasurements/) before this one to get familiar with Pauli measurements.
