# Welcome!

This kata continues the exploration of the Grover's search algorithm started in the [Grover's Algorithm kata](./../GroversAlgorithm/). It teaches writing oracles for the algorithm which describe the problem instead of the solution, using SAT problem as an example. Then it takes the implementation of the Grover's search to the next level, covering the problems with unknown number of solutions.

It is strongly recommended to complete the [Grover's Algorithm kata](./../GroversAlgorithm/) before proceeding to this one. You can also refer to its [README.md](./../GroversAlgorithm/README.md) for the list of resources on Grover's algorithm.

