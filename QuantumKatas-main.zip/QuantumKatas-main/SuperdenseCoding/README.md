# Welcome!

This kata covers superdense coding, a protocol which allows the transmission of two bits of classical information by sending just one qubit that uses previously shared quantum entanglement. This protocol can be thought of as the dual to the teleportation protocol, which allows to transfer the state of a qubit by sending two classical bits.

 - A good description can be found in [the Wikipedia article](https://en.wikipedia.org/wiki/Superdense_coding).
 - A great interactive demonstration can be found [on the Wolfram Demonstrations Project](http://demonstrations.wolfram.com/SuperdenseCoding/).
 - Superdense coding protocol is described in Nielsen & Chuang, section 2.3 (pp. 97-98).
